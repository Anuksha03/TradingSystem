package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;

import com.example.trade.model.TradingModel;
import com.example.trade.repository.TradeRepository;
import com.example.trade.service.TradeService;

@AutoConfigureMockMvc
public class ServiceTests 
{
	@Mock
	private TradeService tradeservice;
	
	@Mock
	private TradeRepository traderepository;
	
	@InjectMocks
	List<TradingModel> itemsList;
	List<TradingModel> itemsList1;
	private TradingModel item1;
	private TradingModel item2;
	
	@BeforeEach
	void setUp() {
		itemsList = new ArrayList<>();
		itemsList1 = new ArrayList<>();
		TradingModel item1 = new TradingModel("agugcug", "uuweihfbi", 20, 10000, 2000, 12345678, 567834, "sd fg rtyh", 345634567, 12345678, "strfyghjn", 8823456701L);
		TradingModel item2 = new TradingModel("hdihihih", "nsbjguhis", 62, 50000, 5000, 2234516, 12345, "asdfgh dfg", 567856778, 456787999, "erfcgvbh", 9876543222L);
		itemsList.add(item1);
		itemsList1.add(item2);
		MockitoAnnotations.initMocks(this);
	}
	/*@AfterEach
    public void tearDown() {
	    item1 = item2 = null;
	    itemsList = null;
    }*/
	
	@Test
	public void addItemTest() {
	TradingModel tm = new TradingModel("agugcug", "uuweihfbi", 20, 10000, 2000, 12345678, 567834, "sd fg rtyh", 345634567, 12345678, "strfyghjn", 8823456701L);
	tradeservice.saveTradeacnum(tm);
	assertThat(tm.getTradeacnum()).isNotNull();
	}
	
	@Test
	public void editSupplierTest() {
		TradingModel updatetm = new TradingModel("agugcug", "rtfghb", 20, 10000, 2000, 12345678, 567834, "sd fg rtyh", 345634567, 12345678, "strfyghjn",8823456701L);
		tradeservice.update(updatetm, 567834);
		
	//	int id=567834;
		assertEquals("rtfghb", updatetm.getStockname());
	//	when(traderepository.save(updatetm)).thenReturn(updatetm);
	//	assertEquals(updatetm,tradeservice.update(updatetm,id));
	}

	@Test
	public void getItemByIdTest() {
		itemsList = new ArrayList<>();
		TradingModel tm = new TradingModel("agugcug", "uuweihfbi", 20, 10000, 2000, 12345678, 567834, "sd fg rtyh", 345634567, 12345678, "strfyghjn",8823456701L);
		tradeservice.saveTradeacnum(tm);
		itemsList.add(tm);
		assertEquals(tm,itemsList.get(0));
	}

	@Test
	void testGetAllItems() {
	itemsList = new ArrayList<>();
	TradingModel tm = new TradingModel("agugcug", "uuweihfbi", 20, 10000, 2000, 12345678, 567834, "sd fg rtyh", 345634567, 12345678, "strfyghjn",8823456701L);
	tradeservice.saveTradeacnum(tm);
	itemsList.add(tm);
	assertEquals(1,itemsList.size());
	}

    @Test
	public void deleteItemTest() {
		itemsList = new ArrayList<>();
		TradingModel tm = new TradingModel("agugcug", "uuweihfbi", 20, 10000, 2000, 12345678, 567834, "sd fg rtyh", 345634567, 12345678, "strfyghjn",8823456701L);
		tradeservice.saveTradeacnum(tm);
		itemsList.remove(tm);
		assertEquals(0,itemsList.size());
    }
}