package com.example.trade.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;
import javax.validation.constraints.NotNull;
//import lombok.AllArgsConstructor;
//import lombok.NoArgsConstructor;

@Entity  
@Data
//@NoArgsConstructor
//@AllArgsConstructor
@Table(name="tradingmodel")
public class TradingModel {
	
	@NotNull
	public String customername;
	@NotNull
	public String stockname;
	@NotNull
	public int stockquantity;
	@NotNull
	public int stockprice; 
	@NotNull
	public int stocklossprice;
	public TradingModel() {
		super();
		// TODO Auto-generated constructor stub
	}

	@NotNull
	public int bankacnum; 
	@NotNull
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	public int tradeacnum;
	@NotNull
	public String address; 
	@NotNull
	private int pan;
	@NotNull
	private int aadhar;
	@NotNull
	public String notes;
	@NotNull
	public long phonenum;
	
//	public TradingModel(String string, String string2, int i, int j, int k, int l, int m, String string3, int n, int o,
//			String string4, String string5) {
		// TODO Auto-generated constructor stub
//	}
	
public String getCustomername() {
		return customername;
	}
	public void setCustomername(String customername) {
		this.customername = customername;
	}
	
	public String getStockname() {
		return stockname;
	}
	public void setStockname(String stockname) {
		this.stockname = stockname;
	}

	public int getStockquantity() {
		return stockquantity;
	}
	public void setStockquantity(int stockquantity) {
		this.stockquantity = stockquantity;
	}
	
	public int getStockprice() {
		return stockprice;
	}
	public void setStockprice(int stockprice) {
		this.stockprice = stockprice;
	}
	
	public int getStocklossprice() {
		return stocklossprice;
	}
	public void setStocklossprice(int stocklossprice) {
		this.stocklossprice = stocklossprice;
	}
	
	public int getBankacnum() {
		return bankacnum;
	}
	public void setBankacnum(int bankacnum) {
		this.bankacnum = bankacnum;
	}
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public int getPan() {
		return pan;
	}
	public void setPan(int pan) {
		this.pan = pan;
	}
	
	public int getAadhar() {
		return aadhar;
	}
	public void setAadhar(int aadhar) {
		this.aadhar = aadhar;
	}
	
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	
	public long getPhonenum() {
		return phonenum;
	}
	public void setPhonenum(long phonenum) {
		this.phonenum = phonenum;
	}
	
	public int getTradeacnum() {
		return tradeacnum;
	}
	public void setTradeacnum(int tradeacnum) {
		this.tradeacnum = tradeacnum;
	}

	@Override
	public String toString() {
		return "TradingModel [customername=" + customername + ", stockname=" + stockname + ", stockquantity="
				+ stockquantity + ", stockprice=" + stockprice + ", stocklossprice=" + stocklossprice + ", bankacnum="
				+ bankacnum + ", tradeacnum=" + tradeacnum + ", address=" + address + ", pan=" + pan + ", aadhar="
				+ aadhar + ", notes=" + notes + ", phonenum=" + phonenum + "]";
	}
	public TradingModel(@NotNull String customername, @NotNull String stockname, @NotNull int stockquantity,
			@NotNull int stockprice, @NotNull int stocklossprice, @NotNull int bankacnum, @NotNull int tradeacnum,
			@NotNull String address, @NotNull int pan, @NotNull int aadhar, @NotNull String notes,
			@NotNull long phonenum) {
		super();
		this.customername = customername;
		this.stockname = stockname;
		this.stockquantity = stockquantity;
		this.stockprice = stockprice;
		this.stocklossprice = stocklossprice;
		this.bankacnum = bankacnum;
		this.tradeacnum = tradeacnum;
		this.address = address;
		this.pan = pan;
		this.aadhar = aadhar;
		this.notes = notes;
		this.phonenum = phonenum;
	}
	
}
