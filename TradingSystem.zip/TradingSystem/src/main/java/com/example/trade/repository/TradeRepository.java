package com.example.trade.repository;
import org.springframework.data.repository.CrudRepository;  
import com.example.trade.model.TradingModel;
public interface TradeRepository extends CrudRepository<TradingModel, Integer> {
}
