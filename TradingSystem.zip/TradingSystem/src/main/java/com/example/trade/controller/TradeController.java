package com.example.trade.controller;
import java.rmi.ServerException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;  
import org.springframework.web.bind.annotation.GetMapping;  
import org.springframework.web.bind.annotation.PathVariable;  
import org.springframework.web.bind.annotation.PostMapping;  
import org.springframework.web.bind.annotation.PutMapping;  
import org.springframework.web.bind.annotation.RequestBody;  
import org.springframework.web.bind.annotation.RestController;

import com.example.trade.model.TradingModel;
import com.example.trade.service.TradeService; 

@RestController  
public class TradeController {
	@Autowired  
	TradeService tradeService;
  
	//get list of data  
	/*@GetMapping("/trade") 
	public ResponseEntity<List<TradingModel>> getAllTradingModel()
	{
		return new ResponseEntity<>(tradeService.getAllTradingModel(), HttpStatus.OK);
	}*/
	
	@GetMapping("/trade")
	public List<TradingModel> getAllTradingModel(){
		return tradeService.getAllTradingModel();
	}
	
	//get specific data
	@GetMapping("/trade/{tradeacnum}")  
	public ResponseEntity<TradingModel> getTradingModel(@PathVariable("tradeacnum") int tradeacnum)   
	{  
		return new ResponseEntity<>(tradeService.getTradingModelById(tradeacnum), HttpStatus.OK) ;  
	}  
	
	//delete specific data
	@DeleteMapping("/delete/{tradeacnum}")  
	public ResponseEntity<String> deleteTradeacnum(@PathVariable("tradeacnum") int tradeacnum)   
	{  
		return new ResponseEntity<> (tradeService.delete(tradeacnum), HttpStatus.ACCEPTED);  
	}  
	
	//post data
	@PostMapping("/addtrade")  
	public ResponseEntity<String> saveTradeacnum(@RequestBody TradingModel tradeacnum) 	{  
		tradeService.save(tradeacnum);  
		return new ResponseEntity<>("Created", HttpStatus.CREATED );  
	}
	
	/*@PostMapping("/addtrade")
	public ResponseEntity<TradingModel> createTradeacnum(@RequestBody TradingModel tm)
	{
		TradingModel tm1 = tradeService.saveTradeacnum(tm);
		return new ResponseEntity<>(tm, HttpStatus.CREATED);
	}*/
	
	/*@PostMapping("/addtrade")
	private int saveTradeacnum(@RequestBody TradingModel tradeacnum)
	{
		tradeService.save(tradeacnum);
		return tradeacnum.getTradeacnum();
	}*/
	
	//update data
	@PutMapping("/updatetrade/{tradeacnum}")  
	public ResponseEntity<TradingModel> update(@PathVariable int tradeacnum, @RequestBody TradingModel tm)   
	{  
		TradingModel tm1 = tradeService.saveTradeacnum(tm);   
		return new ResponseEntity<>(tm1, HttpStatus.CREATED );    
	}  
 
}
