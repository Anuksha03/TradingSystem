package com.example.trade.service;
import java.util.ArrayList;  
import java.util.List;  
import org.springframework.beans.factory.annotation.Autowired;  
import org.springframework.stereotype.Service; 

import com.example.trade.model.TradingModel;
import com.example.trade.repository.TradeRepository;

@Service 
public class TradeService {
	@Autowired  
	public TradeRepository tradeRepository;  
	
	public List<TradingModel> getAllTradingModel()
	{
		List<TradingModel> tradeacnum = new ArrayList<TradingModel>();
		tradeRepository.findAll().forEach(tradeacnum1->tradeacnum.add(tradeacnum1));
		return tradeacnum;
		//return "Created";
	}
	
	public TradingModel getTradingModelById(int id) 
	{
		return tradeRepository.findById(id).get();
    }
	
	public void save(TradingModel tradeacnum)   
	{  
		tradeRepository.save(tradeacnum);  
	} 
	
	public TradingModel saveTradeacnum(TradingModel tm) {
		// TODO Auto-generated method stub
		//return tradeRepository.save(tm);
		return null;
	}  
	
	//deleting a specific record by using the method deleteById() of CrudRepository  
	public String delete(int id)   
	{  
		tradeRepository.deleteById(id);  
		return "Deleted successfully!!!";
	}  
	//updating a record  
	public String update(TradingModel tradeacnum, int Tradeacnum)   
	{  
		tradeRepository.save(tradeacnum);  
		return "Updated successfully!!!";
	}

	
}
